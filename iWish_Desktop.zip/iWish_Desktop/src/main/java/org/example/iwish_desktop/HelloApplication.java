package org.example.iwish_desktop;

import client.LoginView;
import client.Navigator;
import javafx.application.Application;
import javafx.stage.Stage;

public class HelloApplication extends Application {

    @Override
    public void start(Stage primaryStage) {

        Thread.currentThread().setUncaughtExceptionHandler(
                (thread, throwable) -> {
                    System.err.println("Unhandled Exception Caught:");
                    throwable.printStackTrace();
                }
        );

        try {
            Navigator.setPrimaryStage(primaryStage);
            Navigator.navigateTo(new LoginView().getView());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}