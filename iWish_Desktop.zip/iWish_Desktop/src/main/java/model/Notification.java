package model;

import java.sql.Timestamp;

public class Notification {

    private int notificationId;
    private String message;
    private boolean isRead;
    private Timestamp createdAt;

    public Notification(
            int notificationId,
            String message,
            boolean isRead,
            Timestamp createdAt) {

        this.notificationId = notificationId;
        this.message = message;
        this.isRead = isRead;
        this.createdAt = createdAt;
    }

    public int getNotificationId() {
        return notificationId;
    }

    public String getMessage() {
        return message;
    }

    public boolean isRead() {
        return isRead;
    }

    public Timestamp getCreatedAt() {
        return createdAt;
    }
}