
package model;

public class FriendRequest {

    private int requestId;
    private int senderId;
    private String senderName;

    public FriendRequest(
            int requestId,
            int senderId,
            String senderName) {

        this.requestId = requestId;
        this.senderId = senderId;
        this.senderName = senderName;
    }

    public int getRequestId() {
        return requestId;
    }

    public int getSenderId() {
        return senderId;
    }

    public String getSenderName() {
        return senderName;
    }
}
