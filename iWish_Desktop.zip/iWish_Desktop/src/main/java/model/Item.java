package model;

public class Item {

    private int itemId;
    private String name;
    private double defaultPrice;

    public Item(int itemId, String name, double defaultPrice) {
        this.itemId = itemId;
        this.name = name;
        this.defaultPrice = defaultPrice;
    }

    public Item(String name, double defaultPrice) {
        this.name = name;
        this.defaultPrice = defaultPrice;
    }

    public int getItemId() {
        return itemId;
    }

    public String getName() {
        return name;
    }

    public double getDefaultPrice() {
        return defaultPrice;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDefaultPrice(double defaultPrice) {
        this.defaultPrice = defaultPrice;
    }
}

