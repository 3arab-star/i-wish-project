package database;

import model.FriendRequest;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FriendDAO {

    // ==========================================
    // Send Friend Request
    // ==========================================

    public boolean sendFriendRequest(
            int senderId,
            int receiverId) {

        String sql = """
                INSERT INTO FriendRequests
                (sender_id, receiver_id, status)
                VALUES (?, ?, 'PENDING')
                """;

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(1, senderId);
            statement.setInt(2, receiverId);

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {

            e.printStackTrace();

            return false;
        }
    }


    // ==========================================
    // Get Pending Friend Requests
    // ==========================================

    public List<FriendRequest> getPendingRequests(
            int userId) {

        List<FriendRequest> requests =
                new ArrayList<>();

        String sql = """
                SELECT
                    fr.request_id,
                    fr.sender_id,
                    u.username
                FROM FriendRequests fr
                JOIN Users u
                    ON fr.sender_id = u.user_id
                WHERE fr.receiver_id = ?
                AND fr.status = 'PENDING'
                """;

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(
                    1,
                    userId
            );

            ResultSet resultSet =
                    statement.executeQuery();

            while (resultSet.next()) {

                FriendRequest request =
                        new FriendRequest(
                                resultSet.getInt(
                                        "request_id"
                                ),
                                resultSet.getInt(
                                        "sender_id"
                                ),
                                resultSet.getString(
                                        "username"
                                )
                        );

                requests.add(request);
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return requests;
    }


    // ==========================================
    // Accept Friend Request
    // ==========================================

    public boolean acceptFriendRequest(
            int requestId,
            int senderId,
            int receiverId) {

        String updateRequest = """
                UPDATE FriendRequests
                SET status = 'ACCEPTED'
                WHERE request_id = ?
                """;

        String addFriend = """
                INSERT INTO Friends
                (user1_id, user2_id)
                VALUES (?, ?)
                """;

        try (Connection connection =
                     DatabaseConnection.getConnection()) {

            connection.setAutoCommit(false);

            try {

                PreparedStatement requestStatement =
                        connection.prepareStatement(
                                updateRequest
                        );

                requestStatement.setInt(
                        1,
                        requestId
                );

                requestStatement.executeUpdate();


                PreparedStatement friendStatement =
                        connection.prepareStatement(
                                addFriend
                        );

                friendStatement.setInt(
                        1,
                        senderId
                );

                friendStatement.setInt(
                        2,
                        receiverId
                );

                friendStatement.executeUpdate();


                connection.commit();

                return true;

            } catch (SQLException e) {

                connection.rollback();

                e.printStackTrace();

                return false;
            }

        } catch (SQLException e) {

            e.printStackTrace();

            return false;
        }
    }


    // ==========================================
    // Decline Friend Request
    // ==========================================

    public boolean declineFriendRequest(
            int requestId) {

        String sql = """
                UPDATE FriendRequests
                SET status = 'DECLINED'
                WHERE request_id = ?
                """;

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(
                    1,
                    requestId
            );

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {

            e.printStackTrace();

            return false;
        }
    }


    // ==========================================
    // Get Friends
    // ==========================================

    public List<Integer> getFriends(
            int userId) {

        List<Integer> friendIds =
                new ArrayList<>();

        String sql = """
                SELECT
                    CASE
                        WHEN user1_id = ?
                        THEN user2_id
                        ELSE user1_id
                    END AS friend_id
                FROM Friends
                WHERE user1_id = ?
                   OR user2_id = ?
                """;

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(1, userId);
            statement.setInt(2, userId);
            statement.setInt(3, userId);

            ResultSet resultSet =
                    statement.executeQuery();

            while (resultSet.next()) {

                friendIds.add(
                        resultSet.getInt(
                                "friend_id"
                        )
                );
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return friendIds;
    }


    // ==========================================
    // Remove Friend
    // ==========================================

    public boolean removeFriend(
            int userId,
            int friendId) {

        String sql = """
                DELETE FROM Friends
                WHERE
                (user1_id = ? AND user2_id = ?)
                OR
                (user1_id = ? AND user2_id = ?)
                """;

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(1, userId);
            statement.setInt(2, friendId);

            statement.setInt(3, friendId);
            statement.setInt(4, userId);

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {

            e.printStackTrace();

            return false;
        }
    }
}
