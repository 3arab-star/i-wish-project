package database;

import model.Item;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ItemDAO {

    // ==========================================
    // Add a new item (Prevents Duplication)
    // ==========================================

    public int addItem(Item item) {

        // 1. التاكد أولاً ما إذا كان العنصر موجوداً بالفعل في قاعدة البيانات
        Item existingItem = findItemByName(item.getName().trim());

        if (existingItem != null) {
            // إرجاع الـ ID الخاص بالعنصر الموجود سابقاً دون إنشاء واحد جديد
            return existingItem.getItemId();
        }

        // 2. في حالة عدم وجوده، يتم إضافته كعنصر جديد
        String sql =
                "INSERT INTO Items (name, default_price) VALUES (?, ?)";

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(
                             sql,
                             java.sql.Statement.RETURN_GENERATED_KEYS
                     )) {

            statement.setString(
                    1,
                    item.getName().trim()
            );

            statement.setDouble(
                    2,
                    item.getDefaultPrice()
            );

            int rowsInserted =
                    statement.executeUpdate();

            if (rowsInserted > 0) {

                ResultSet resultSet =
                        statement.getGeneratedKeys();

                if (resultSet.next()) {

                    return resultSet.getInt(1);
                }
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return -1;
    }


    // ==========================================
    // Get all items
    // ==========================================

    public List<Item> getAllItems() {

        List<Item> items =
                new ArrayList<>();

        String sql =
                "SELECT * FROM Items ORDER BY name";

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(sql);

             ResultSet resultSet =
                     statement.executeQuery()) {

            while (resultSet.next()) {

                Item item =
                        new Item(
                                resultSet.getInt("item_id"),
                                resultSet.getString("name"),
                                resultSet.getDouble("default_price")
                        );

                items.add(item);
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return items;
    }


    // ==========================================
    // Find item by name (Case-Insensitive)
    // ==========================================

    public Item findItemByName(String name) {

        String sql =
                "SELECT * FROM Items WHERE LOWER(name) = LOWER(?)";

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setString(
                    1,
                    name.trim()
            );

            ResultSet resultSet =
                    statement.executeQuery();

            if (resultSet.next()) {

                return new Item(
                        resultSet.getInt("item_id"),
                        resultSet.getString("name"),
                        resultSet.getDouble("default_price")
                );
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return null;
    }


    // ==========================================
    // Get item by ID
    // ==========================================

    public Item getItemById(int itemId) {

        String sql =
                "SELECT * FROM Items WHERE item_id = ?";

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(
                    1,
                    itemId
            );

            ResultSet resultSet =
                    statement.executeQuery();

            if (resultSet.next()) {

                return new Item(
                        resultSet.getInt("item_id"),
                        resultSet.getString("name"),
                        resultSet.getDouble("default_price")
                );
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return null;
    }
}