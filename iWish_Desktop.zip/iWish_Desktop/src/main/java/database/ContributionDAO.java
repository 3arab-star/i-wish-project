package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ContributionDAO {

    // ==========================================
    // Add Contribution
    // ==========================================

    public boolean addContribution(
            int wishlistId,
            int buyerId,
            double amount) {

        String sql = """
                INSERT INTO Contributions
                (wishlist_id, buyer_id, amount)
                VALUES (?, ?, ?)
                """;

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(1, wishlistId);
            statement.setInt(2, buyerId);
            statement.setDouble(3, amount);

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {

            e.printStackTrace();

            return false;
        }
    }


    // ==========================================
    // Get Total Contributed So Far (by wishlist_id)
    // ==========================================

    public double getTotalContributed(
            int wishlistId) {

        String sql = """
                SELECT COALESCE(SUM(amount), 0) AS total
                FROM Contributions
                WHERE wishlist_id = ?
                """;

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(1, wishlistId);

            ResultSet resultSet =
                    statement.executeQuery();

            if (resultSet.next()) {

                return resultSet.getDouble("total");
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return 0;
    }


    // ==========================================
    // Get Distinct Buyers Who Contributed
    // ==========================================

    public List<Integer> getBuyerIds(
            int wishlistId) {

        List<Integer> buyerIds =
                new ArrayList<>();

        String sql = """
                SELECT DISTINCT buyer_id
                FROM Contributions
                WHERE wishlist_id = ?
                """;

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(1, wishlistId);

            ResultSet resultSet =
                    statement.executeQuery();

            while (resultSet.next()) {

                buyerIds.add(
                        resultSet.getInt("buyer_id")
                );
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return buyerIds;
    }
}