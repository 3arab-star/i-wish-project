package database;

import model.Notification;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class NotificationDAO {

    // ==========================================
    // Add Notification
    // ==========================================

    public boolean addNotification(
            int userId,
            String message) {

        String sql = """
                INSERT INTO Notifications
                (user_id, message)
                VALUES (?, ?)
                """;

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(1, userId);
            statement.setString(2, message);

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {

            e.printStackTrace();

            return false;
        }
    }


    // ==========================================
    // Get Notifications For A User (newest first)
    // ==========================================

    public List<Notification> getNotifications(
            int userId) {

        List<Notification> notifications =
                new ArrayList<>();

        String sql = """
                SELECT notification_id, message, is_read, created_at
                FROM Notifications
                WHERE user_id = ?
                ORDER BY created_at DESC
                """;

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(1, userId);

            ResultSet resultSet =
                    statement.executeQuery();

            while (resultSet.next()) {

                Notification notification =
                        new Notification(
                                resultSet.getInt("notification_id"),
                                resultSet.getString("message"),
                                resultSet.getBoolean("is_read"),
                                resultSet.getTimestamp("created_at")
                        );

                notifications.add(notification);
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return notifications;
    }


    // ==========================================
    // Mark A Notification As Read
    // ==========================================

    public boolean markAsRead(
            int notificationId) {

        String sql = """
                UPDATE Notifications
                SET is_read = TRUE
                WHERE notification_id = ?
                """;

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(1, notificationId);

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {

            e.printStackTrace();

            return false;
        }
    }


    // ==========================================
    // Get Unread Count For A User
    // ==========================================

    public int getUnreadCount(
            int userId) {

        String sql = """
                SELECT COUNT(*) AS unread
                FROM Notifications
                WHERE user_id = ?
                AND is_read = FALSE
                """;

        try (Connection connection =
                     DatabaseConnection.getConnection();

             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setInt(1, userId);

            ResultSet resultSet =
                    statement.executeQuery();

            if (resultSet.next()) {

                return resultSet.getInt("unread");
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return 0;
    }
}