package database;

import model.Item;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class WishlistDAO {

    // Add an item to user's wishlist
    public boolean addToWishlist(int userId, int itemId, double price) {

        String sql = """
                INSERT INTO WishList (user_id, item_id, price, status)
                VALUES (?, ?, ?, 'ACTIVE')
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, userId);
            statement.setInt(2, itemId);
            statement.setDouble(3, price);

            int rowsInserted = statement.executeUpdate();

            return rowsInserted > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    // Get user's wishlist
    public List<Item> getWishlist(int userId) {

        List<Item> items = new ArrayList<>();

        String sql = """
                SELECT i.item_id, i.name, w.price
                FROM WishList w
                JOIN Items i ON w.item_id = i.item_id
                WHERE w.user_id = ? AND w.status = 'ACTIVE'
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, userId);

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {

                Item item = new Item(
                        resultSet.getInt("item_id"),
                        resultSet.getString("name"),
                        resultSet.getDouble("price")
                );

                items.add(item);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return items;
    }


    // Remove an item from wishlist
    public boolean removeFromWishlist(int userId, int itemId) {

        String sql = """
                DELETE FROM WishList
                WHERE user_id = ? AND item_id = ?
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, userId);
            statement.setInt(2, itemId);

            int rowsDeleted = statement.executeUpdate();

            return rowsDeleted > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    // Get Wishlist ID (for a specific user + item)
    public int getWishlistId(int userId, int itemId) {

        String sql = """
                SELECT wishlist_id
                FROM WishList
                WHERE user_id = ?
                AND item_id = ?
                AND status = 'ACTIVE'
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, userId);
            statement.setInt(2, itemId);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {

                return resultSet.getInt("wishlist_id");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1;
    }


    // Get Price For A Wishlist Row
    public double getPrice(int wishlistId) {

        String sql = """
                SELECT price
                FROM WishList
                WHERE wishlist_id = ?
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, wishlistId);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {

                return resultSet.getDouble("price");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return -1;
    }


    // Update Wishlist Item Price
    public boolean updateWishlistItem(
            int userId,
            int itemId,
            double newPrice) {

        String sql = """
                UPDATE WishList
                SET price = ?
                WHERE user_id = ?
                AND item_id = ?
                AND status = 'ACTIVE'
                """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setDouble(1, newPrice);
            statement.setInt(2, userId);
            statement.setInt(3, itemId);

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}