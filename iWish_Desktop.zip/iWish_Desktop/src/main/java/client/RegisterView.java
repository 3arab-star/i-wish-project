package client;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

public class RegisterView {

    public Parent getView() {

        Label title = new Label("Create Account");
        title.getStyleClass().add("title");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username");
        usernameField.getStyleClass().add("input-field");

        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        emailField.getStyleClass().add("input-field");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        passwordField.getStyleClass().add("input-field");

        PasswordField confirmPasswordField = new PasswordField();
        confirmPasswordField.setPromptText("Confirm Password");
        confirmPasswordField.getStyleClass().add("input-field");

        Button registerButton = new Button("Register");
        registerButton.getStyleClass().add("register-button");

        Button backButton = new Button("Back to Login");
        backButton.getStyleClass().add("link-button");

        Label messageLabel = new Label();
        messageLabel.getStyleClass().add("message");

        registerButton.setOnAction(event -> {

            String username = usernameField.getText();
            String email = emailField.getText();
            String password = passwordField.getText();
            String confirmPassword = confirmPasswordField.getText();

            if (username.isEmpty()
                    || email.isEmpty()
                    || password.isEmpty()
                    || confirmPassword.isEmpty()) {

                messageLabel.setText("Please fill all fields.");
                return;
            }

            if (!password.equals(confirmPassword)) {

                messageLabel.setText("Passwords do not match.");
                return;
            }

            RegisterController controller =
                    new RegisterController();

            String message = controller.register(
                    username,
                    email,
                    password
            );

            messageLabel.setText(message);
        });

        backButton.setOnAction(
                event -> Navigator.goBack()
        );

        VBox root = new VBox(15);

        root.setPadding(new Insets(30));
        root.setAlignment(Pos.CENTER);
        root.getStyleClass().add("register-root");

        root.getChildren().addAll(
                title,
                usernameField,
                emailField,
                passwordField,
                confirmPasswordField,
                registerButton,
                backButton,
                messageLabel
        );

        return root;
    }
}