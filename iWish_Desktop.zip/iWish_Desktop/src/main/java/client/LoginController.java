package client;

import database.UserDAO;
import model.User;

public class LoginController {

    private UserDAO userDAO;

    public LoginController() {
        userDAO = new UserDAO();
    }

    public User login(String username, String password) {

        return userDAO.loginUser(username, password);
    }
}