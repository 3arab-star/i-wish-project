package client;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import model.FriendRequest;
import model.User;

public class FriendRequestsView {

    public Parent getView(User user) {

        FriendController controller = new FriendController();

        Label title = new Label("Friend Requests");
        title.getStyleClass().add("title");

        Label message = new Label(
                "Manage your friend requests. ✨"
        );
        message.getStyleClass().add("message");

        ListView<FriendRequest> requestsList =
                new ListView<>();

        requestsList.getItems().addAll(
                controller.getPendingRequests(
                        user.getUserId()
                )
        );

        requestsList.setPrefSize(700, 350);

        requestsList.setCellFactory(listView ->
                new ListCell<>() {

                    @Override
                    protected void updateItem(
                            FriendRequest request,
                            boolean empty) {

                        super.updateItem(
                                request,
                                empty
                        );

                        if (empty || request == null) {

                            setText(null);
                            setGraphic(null);

                        } else {

                            Label nameLabel =
                                    new Label(
                                            request.getSenderName()
                                    );

                            Button acceptButton =
                                    new Button("Accept");

                            acceptButton
                                    .getStyleClass()
                                    .add("register-button");

                            acceptButton.setPrefSize(
                                    100,
                                    40
                            );

                            Button declineButton =
                                    new Button("Decline");

                            declineButton
                                    .getStyleClass()
                                    .add("link-button");

                            declineButton.setPrefSize(
                                    100,
                                    40
                            );

                            acceptButton.setOnAction(event -> {

                                boolean accepted =
                                        controller.acceptRequest(
                                                request.getRequestId(),
                                                request.getSenderId(),
                                                user.getUserId()
                                        );

                                if (accepted) {
                                    requestsList
                                            .getItems()
                                            .remove(request);
                                }
                            });

                            declineButton.setOnAction(event -> {

                                boolean declined =
                                        controller.declineRequest(
                                                request.getRequestId()
                                        );

                                if (declined) {
                                    requestsList
                                            .getItems()
                                            .remove(request);
                                }
                            });

                            HBox row =
                                    new HBox(20);

                            row.setPadding(
                                    new Insets(10)
                            );

                            row.setAlignment(
                                    Pos.CENTER_LEFT
                            );

                            row.getChildren().addAll(
                                    nameLabel,
                                    acceptButton,
                                    declineButton
                            );

                            setGraphic(row);
                        }
                    }
                }
        );

        VBox root =
                new VBox(18);

        root.setPadding(
                new Insets(30)
        );

        root.setAlignment(
                Pos.CENTER
        );

        root.getStyleClass()
                .add("register-root");

        root.getChildren().addAll(
                title,
                message,
                requestsList
        );

        return root;
    }
}