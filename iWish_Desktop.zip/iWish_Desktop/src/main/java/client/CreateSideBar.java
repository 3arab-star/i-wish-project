package client;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import model.User;

public class CreateSideBar {

    public static VBox createSideBar(User user) {

        // ==========================================
        // Logo
        // ==========================================

        Label logo = new Label("iWish");
        logo.getStyleClass().add("sidebar-logo");

        // ==========================================
        // Navigation Buttons
        // ==========================================

        Button homeButton = createButton("Home");
        homeButton.setOnAction(event ->
                Navigator.navigateTo(new HomeView().getView(user))
        );

        Button wishlistButton = createButton("My Wishlist");
        wishlistButton.setOnAction(event ->
                Navigator.navigateTo(new WishlistView().getView(user))
        );

        Button friendsButton = createButton("Friends");
        friendsButton.setOnAction(event ->
                Navigator.navigateTo(new FriendsView().getView(user))
        );

        Button notificationsButton = createButton("Notifications");
        notificationsButton.setOnAction(event ->
                Navigator.navigateTo(new NotificationsView().getView(user))
        );

        // ==========================================
        // Logout
        // ==========================================

        Button logoutButton = new Button("Logout");
        logoutButton.getStyleClass().add("sidebar-logout-btn");
        logoutButton.setMaxWidth(Double.MAX_VALUE);
        logoutButton.setAlignment(Pos.CENTER_LEFT);

        logoutButton.setOnAction(event -> {

            Navigator.setCurrentUser(null);
            Navigator.clearHistory();
            Navigator.navigateTo(new LoginView().getView());
        });

// ==========================================
        // Assembly
        // ==========================================

        // Create the first spacer for below the logo
        Region topSpacer = new Region();
        topSpacer.getStyleClass().add("sidebar-spacer");
        // VGrow might not be needed here if you only want it to push the logout button down, 
        // but if you want equal spacing, you can keep it.
        topSpacer.setPrefHeight(20); 

        // Create a separate spacer to push the logout button to the bottom
        Region bottomSpacer = new Region();
        bottomSpacer.getStyleClass().add("sidebar-spacer");
        VBox.setVgrow(bottomSpacer, javafx.scene.layout.Priority.ALWAYS);

        VBox sidebar = new VBox(4);
        sidebar.setPadding(new Insets(20, 12, 16, 12));
        sidebar.setPrefWidth(220);
        sidebar.getStyleClass().add("sidebar");

        sidebar.getChildren().addAll(
                logo,
                topSpacer, // Use instance 1
                homeButton,
                wishlistButton,
                friendsButton,
                notificationsButton,
                bottomSpacer, // Use instance 2
                logoutButton
        );

        return sidebar;
    }

    private static Button createButton(String text) {

        Button button = new Button(text);
        button.getStyleClass().add("sidebar-btn");
        button.setMaxWidth(Double.MAX_VALUE);
        button.setAlignment(Pos.CENTER_LEFT);

        return button;
    }
}
