package client;

import java.util.List;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.User;

public class FriendsView {

    public Parent getView(User user) {

        FriendController controller = new FriendController();

        Label title = new Label("My Friends");
        title.getStyleClass().add("title");

        Label message = new Label(
                "Connect with your friends and share the joy. ✨"
        );
        message.getStyleClass().add("message");

        ListView<User> friendsList = new ListView<>();

        for (Integer friendId :
                controller.getFriends(user.getUserId())) {

            User friend = controller.getUserById(friendId);

            if (friend != null) {
                friendsList.getItems().add(friend);
            }
        }

        friendsList.setPrefSize(700, 350);

        friendsList.setCellFactory(listView ->
                new ListCell<>() {

                    @Override
                    protected void updateItem(
                            User friend,
                            boolean empty) {

                        super.updateItem(friend, empty);

                        if (empty || friend == null) {

                            setText(null);
                            setGraphic(null);

                        } else {

                            Label nameLabel =
                                    new Label(friend.getUsername());

                            Button viewWishlistButton =
                                    new Button("View Wishlist");

                            viewWishlistButton
                                    .getStyleClass()
                                    .add("register-button");

                            viewWishlistButton
                                    .setPrefSize(140, 40);

                            viewWishlistButton.setOnAction(event ->
                                    Navigator.navigateTo(
                                            new FriendWishlistView()
                                                    .getView(user, friend)
                                    )
                            );

                            Button removeButton =
                                    new Button("Remove");

                            removeButton
                                    .getStyleClass()
                                    .add("link-button");

                            removeButton
                                    .setPrefSize(100, 40);

                            removeButton.setOnAction(event -> {

                                boolean removed =
                                        controller.removeFriend(
                                                user.getUserId(),
                                                friend.getUserId()
                                        );

                                if (removed) {
                                    friendsList
                                            .getItems()
                                            .remove(friend);
                                }
                            });

                            HBox row =
                                    new HBox(20);

                            row.setPadding(
                                    new Insets(10)
                            );

                            row.setAlignment(
                                    Pos.CENTER_LEFT
                            );

                            row.getChildren().addAll(
                                    nameLabel,
                                    viewWishlistButton,
                                    removeButton
                            );

                            setGraphic(row);
                        }
                    }
                }
        );

        Button addFriendButton =
                new Button("Add Friend");

        addFriendButton
                .getStyleClass()
                .add("register-button");

        addFriendButton.setPrefSize(
                200,
                50
        );

        addFriendButton.setOnAction(event ->
                showAddFriendWindow(
                        user,
                        controller
                )
        );

        Button requestsButton =
                new Button("Friend Requests");

        requestsButton
                .getStyleClass()
                .add("register-button");

        requestsButton.setPrefSize(
                200,
                50
        );

        requestsButton.setOnAction(event ->
                Navigator.navigateTo(
                        new FriendRequestsView()
                                .getView(user)
                )
        );

        HBox buttons =
                new HBox(20);

        buttons.setAlignment(
                Pos.CENTER
        );

        buttons.getChildren().addAll(
                addFriendButton,
                requestsButton
        );

        VBox root =
                new VBox(18);

        root.setPadding(
                new Insets(30)
        );

        root.setAlignment(
                Pos.CENTER
        );

        root.getStyleClass()
                .add("register-root");

        root.getChildren().addAll(
                title,
                message,
                friendsList,
                buttons
        );

        return root;
    }

    private void showAddFriendWindow(
            User user,
            FriendController controller) {

        Stage stage = new Stage();

        Label title =
                new Label("Add Friend");

        title.getStyleClass()
                .add("title");

        TextField emailField =
                new TextField();

        emailField.setPromptText(
                "Friend's Email"
        );

        emailField.getStyleClass()
                .add("input-field");

        Label messageLabel =
                new Label();

        messageLabel.getStyleClass()
                .add("message");

        Button sendButton =
                new Button("Send Request");

        sendButton.getStyleClass()
                .add("register-button");

        sendButton.setPrefSize(
                180,
                48
        );

        sendButton.setOnAction(event -> {

            String email =
                    emailField.getText().trim();

            if (email.isEmpty()) {

                messageLabel.setText(
                        "Please enter an email."
                );

                return;
            }

            User receiver =
                    controller.getUserByEmail(email);

            if (receiver == null) {

                messageLabel.setText(
                        "User not found."
                );

                return;
            }

            if (receiver.getUserId()
                    == user.getUserId()) {

                messageLabel.setText(
                        "You cannot add yourself."
                );

                return;
            }

            List<Integer> currentFriends =
                    controller.getFriends(
                            user.getUserId()
                    );

            if (currentFriends.contains(
                    receiver.getUserId())) {

                messageLabel.setText(
                        "This user is already your friend!"
                );

                return;
            }

            boolean sent =
                    controller.sendRequest(
                            user.getUserId(),
                            receiver.getUserId()
                    );

            if (sent) {

                messageLabel.setText(
                        "Friend request sent!"
                );

                emailField.clear();

            } else {

                messageLabel.setText(
                        "Request already pending or could not be sent."
                );
            }
        });

        Button closeButton =
                new Button("Close");

        closeButton.getStyleClass()
                .add("link-button");

        closeButton.setPrefSize(
                120,
                40
        );

        closeButton.setOnAction(
                event -> stage.close()
        );

        VBox root =
                new VBox(20);

        root.setPadding(
                new Insets(30)
        );

        root.setAlignment(
                Pos.CENTER
        );

        root.getStyleClass()
                .add("register-root");

        root.getChildren().addAll(
                title,
                emailField,
                sendButton,
                messageLabel,
                closeButton
        );

        Scene scene =
                new Scene(root, 450, 400);

        scene.getStylesheets().add(
                getClass()
                        .getResource("/style.css")
                        .toExternalForm()
        );

        stage.setTitle(
                "iWish - Add Friend"
        );

        stage.setScene(scene);
        stage.show();
    }
}