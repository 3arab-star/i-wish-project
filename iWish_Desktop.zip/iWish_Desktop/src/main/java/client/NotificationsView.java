package client;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import model.Notification;
import model.User;

public class NotificationsView {

    public Parent getView(User user) {

        NotificationController controller =
                new NotificationController();

        Label title =
                new Label("Notifications");

        title.getStyleClass()
                .add("title");

        Label message =
                new Label(
                        "Stay updated with what's happening on iWish. ✨"
                );

        message.getStyleClass()
                .add("message");

        ListView<Notification> notificationsList =
                new ListView<>();

        notificationsList.getItems().addAll(
                controller.getNotifications(
                        user.getUserId()
                )
        );

        notificationsList.setPrefSize(
                700,
                350
        );

        notificationsList.setPlaceholder(
                new Label(
                        "You have no notifications yet."
                )
        );

        notificationsList.setCellFactory(listView ->
                new ListCell<>() {

                    @Override
                    protected void updateItem(
                            Notification notification,
                            boolean empty) {

                        super.updateItem(
                                notification,
                                empty
                        );

                        if (empty || notification == null) {

                            setText(null);
                            setGraphic(null);

                        } else {

                            Label messageLabel =
                                    new Label(
                                            notification.getMessage()
                                    );

                            messageLabel.setWrapText(
                                    true
                            );

                            messageLabel
                                    .getStyleClass()
                                    .add(
                                            notification.isRead()
                                                    ? "notification-read"
                                                    : "notification-unread"
                                    );

                            Button dismissButton =
                                    new Button("Dismiss");

                            dismissButton
                                    .getStyleClass()
                                    .add("link-button");

                            dismissButton.setPrefSize(
                                    100,
                                    40
                            );

                            dismissButton.setDisable(
                                    notification.isRead()
                            );

                            dismissButton.setOnAction(
                                    event -> {

                                        boolean marked =
                                                controller.markAsRead(
                                                        notification
                                                                .getNotificationId()
                                                );

                                        if (marked) {

                                            dismissButton
                                                    .setDisable(
                                                            true
                                                    );

                                            messageLabel
                                                    .getStyleClass()
                                                    .remove(
                                                            "notification-unread"
                                                    );

                                            messageLabel
                                                    .getStyleClass()
                                                    .add(
                                                            "notification-read"
                                                    );
                                        }
                                    }
                            );

                            HBox row =
                                    new HBox(20);

                            row.setPadding(
                                    new Insets(10)
                            );

                            row.setAlignment(
                                    Pos.CENTER_LEFT
                            );

                            row.getChildren().addAll(
                                    messageLabel,
                                    dismissButton
                            );

                            setGraphic(row);
                        }
                    }
                }
        );

        VBox root =
                new VBox(18);

        root.setPadding(
                new Insets(30)
        );

        root.setAlignment(
                Pos.CENTER
        );

        root.getStyleClass()
                .add("register-root");

        root.getChildren().addAll(
                title,
                message,
                notificationsList
        );

        return root;
    }
}