package client;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.Item;
import model.User;

public class FriendWishlistView {

    public Parent getView(User viewer, User friend) {

        WishlistController wishlistController =
                new WishlistController();

        Label title =
                new Label(friend.getUsername() + "'s Wishlist");

        title.getStyleClass().add("title");

        Label message =
                new Label(
                        "Help make your friend's wishes come true. ✨"
                );

        message.getStyleClass().add("message");

        ListView<Item> wishlistList =
                new ListView<>();

        wishlistList.getItems().addAll(
                wishlistController.getWishlist(
                        friend.getUserId()
                )
        );

        wishlistList.setPrefSize(700, 350);

        wishlistList.setCellFactory(listView ->
                new ListCell<>() {

                    @Override
                    protected void updateItem(
                            Item item,
                            boolean empty) {

                        super.updateItem(
                                item,
                                empty
                        );

                        if (empty || item == null) {

                            setText(null);
                            setGraphic(null);

                        } else {

                            double price =
                                    item.getDefaultPrice();

                            double contributed =
                                    wishlistController
                                            .getTotalContributed(
                                                    friend.getUserId(),
                                                    item.getItemId()
                                            );

                            boolean fullyFunded =
                                    contributed >= price;

                            Label itemLabel =
                                    new Label(
                                            item.getName()
                                                    + " - "
                                                    + price
                                                    + " EGP"
                                                    + (fullyFunded
                                                    ? " (Fully Funded)"
                                                    : " ("
                                                    + contributed
                                                    + " / "
                                                    + price
                                                    + " funded)")
                                    );

                            Button contributeButton =
                                    new Button("Contribute");

                            contributeButton
                                    .getStyleClass()
                                    .add("register-button");

                            contributeButton.setPrefSize(
                                    130,
                                    40
                            );

                            contributeButton.setDisable(
                                    fullyFunded
                            );

                            contributeButton.setOnAction(
                                    event ->
                                            showContributeWindow(
                                                    viewer,
                                                    friend,
                                                    item,
                                                    wishlistController,
                                                    wishlistList
                                            )
                            );

                            HBox row =
                                    new HBox(20);

                            row.setPadding(
                                    new Insets(10)
                            );

                            row.setAlignment(
                                    Pos.CENTER_LEFT
                            );

                            row.getChildren().addAll(
                                    itemLabel,
                                    contributeButton
                            );

                            setGraphic(row);
                        }
                    }
                }
        );

        if (wishlistList.getItems().isEmpty()) {

            wishlistList.setPlaceholder(
                    new Label(
                            friend.getUsername()
                                    + " has no items in their wishlist yet."
                    )
            );
        }

        VBox root =
                new VBox(18);

        root.setPadding(
                new Insets(30)
        );

        root.setAlignment(
                Pos.CENTER
        );

        root.getStyleClass()
                .add("register-root");

        root.getChildren().addAll(
                title,
                message,
                wishlistList
        );

        return root;
    }

    private void showContributeWindow(
            User viewer,
            User friend,
            Item item,
            WishlistController wishlistController,
            ListView<Item> wishlistList) {

        Stage stage =
                new Stage();

        Label title =
                new Label(
                        "Contribute to \""
                                + item.getName()
                                + "\""
                );

        title.getStyleClass()
                .add("title");

        double price =
                item.getDefaultPrice();

        double contributed =
                wishlistController.getTotalContributed(
                        friend.getUserId(),
                        item.getItemId()
                );

        double remaining =
                wishlistController.getRemainingAmount(
                        friend.getUserId(),
                        item.getItemId()
                );

        Label infoLabel =
                new Label(
                        "Price: "
                                + price
                                + " EGP"
                                + "\nAlready funded: "
                                + contributed
                                + " EGP"
                                + "\nRemaining: "
                                + remaining
                                + " EGP"
                );

        infoLabel.getStyleClass()
                .add("message");

        TextField amountField =
                new TextField();

        amountField.setPromptText(
                "Amount to contribute (EGP)"
        );

        amountField.getStyleClass()
                .add("input-field");

        Label messageLabel =
                new Label();

        messageLabel.getStyleClass()
                .add("message");

        Button confirmButton =
                new Button(
                        "Confirm Contribution"
                );

        confirmButton
                .getStyleClass()
                .add("register-button");

        confirmButton.setPrefSize(
                200,
                48
        );

        confirmButton.setOnAction(event -> {

            String amountText =
                    amountField.getText().trim();

            if (amountText.isEmpty()) {

                messageLabel.setText(
                        "Please enter an amount."
                );

                return;
            }

            double amount;

            try {

                amount =
                        Double.parseDouble(
                                amountText
                        );

            } catch (NumberFormatException e) {

                messageLabel.setText(
                        "Please enter a valid number."
                );

                return;
            }

            if (amount <= 0) {

                messageLabel.setText(
                        "Amount must be greater than 0."
                );

                return;
            }

            double currentRemaining =
                    wishlistController
                            .getRemainingAmount(
                                    friend.getUserId(),
                                    item.getItemId()
                            );

            if (amount > currentRemaining) {

                messageLabel.setText(
                        "Amount exceeds the remaining "
                                + currentRemaining
                                + " EGP needed."
                );

                return;
            }

            if (friend.getUserId()
                    == viewer.getUserId()) {

                messageLabel.setText(
                        "You cannot contribute to your own wishlist."
                );

                return;
            }

            boolean success =
                    wishlistController.contribute(
                            friend.getUserId(),
                            item.getItemId(),
                            viewer.getUserId(),
                            amount
                    );

            if (success) {

                messageLabel.setText(
                        "Thank you for your contribution!"
                );

                wishlistList.getItems().setAll(
                        wishlistController.getWishlist(
                                friend.getUserId()
                        )
                );

                stage.close();

            } else {

                messageLabel.setText(
                        "Failed to save contribution."
                );
            }
        });

        Button cancelButton =
                new Button("Cancel");

        cancelButton
                .getStyleClass()
                .add("link-button");

        cancelButton.setPrefSize(
                120,
                40
        );

        cancelButton.setOnAction(
                event -> stage.close()
        );

        VBox root =
                new VBox(15);

        root.setPadding(
                new Insets(30)
        );

        root.setAlignment(
                Pos.CENTER
        );

        root.getStyleClass()
                .add("register-root");

        root.getChildren().addAll(
                title,
                infoLabel,
                amountField,
                confirmButton,
                messageLabel,
                cancelButton
        );

        Scene scene =
                new Scene(
                        root,
                        420,
                        400
                );

        scene.getStylesheets().add(
                getClass()
                        .getResource("/style.css")
                        .toExternalForm()
        );

        stage.setTitle(
                "iWish - Contribute"
        );

        stage.setScene(scene);
        stage.show();
    }
}