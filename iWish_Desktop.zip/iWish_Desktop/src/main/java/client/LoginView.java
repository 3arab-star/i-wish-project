package client;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import model.User;

public class LoginView {

    public Parent getView() {

        Label title = new Label("Welcome Back");
        title.getStyleClass().add("title");

        Label subtitle = new Label(
                "Sign in to keep chasing your dreams. ✨"
        );
        subtitle.getStyleClass().add("message");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Username or Email");
        usernameField.getStyleClass().add("input-field");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Password");
        passwordField.getStyleClass().add("input-field");

        Label messageLabel = new Label();
        messageLabel.getStyleClass().add("message");

        Button loginButton = new Button("Login");
        loginButton.getStyleClass().add("register-button");
        loginButton.setPrefSize(180, 46);

        Button registerButton = new Button("Create New Account");
        registerButton.getStyleClass().add("link-button");
        registerButton.setPrefSize(180, 40);

        LoginController controller = new LoginController();

        loginButton.setOnAction(event -> {

            String username = usernameField.getText().trim();
            String password = passwordField.getText().trim();

            if (username.isEmpty() || password.isEmpty()) {
                messageLabel.setText("Please fill all fields.");
                return;
            }

            User user = controller.login(username, password);

            if (user != null) {

                Navigator.setCurrentUser(user);
                Navigator.clearHistory();
                Navigator.navigateTo(new HomeView().getView(user));

            } else {

                messageLabel.setText(
                        "Invalid username or password."
                );
            }
        });

        registerButton.setOnAction(event ->
                Navigator.navigateTo(new RegisterView().getView())
        );

        VBox root = new VBox(14);
        root.setPadding(new Insets(28));
        root.setAlignment(Pos.CENTER);
        root.getStyleClass().add("register-root");

        root.getChildren().addAll(
                title,
                subtitle,
                usernameField,
                passwordField,
                loginButton,
                registerButton,
                messageLabel
        );

        return root;
    }
}