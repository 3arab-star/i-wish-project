package client;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import model.Item;
import model.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.util.List;

public class HomeView {

    public Parent getView(User user) {

        // ==========================================
        // Header
        // ==========================================

        Label header = new Label("iWish");
        header.getStyleClass().add("home-header");

        Label welcome = new Label(
                "Hello, " + user.getUsername() + "! 💙"
        );
        welcome.getStyleClass().add("home-welcome");

        Label message = new Label(
                "Wish it. Share it. Make someone happy. ✨"
        );
        message.getStyleClass().add("message");

        // ==========================================
        // Recent Friends
        // ==========================================

        Label friendsTitle = new Label("Recent Friends");
        friendsTitle.getStyleClass().add("section-title");

        ListView<User> friendsList = new ListView<>();
        friendsList.setPrefHeight(220);

        FriendController friendController = new FriendController();
        List<Integer> friendIds = friendController.getFriends(user.getUserId());
        ObservableList<User> friendItems = FXCollections.observableArrayList();

        int shown = 0;
        for (Integer friendId : friendIds) {
            if (shown >= 4) break;
            User friend = friendController.getUserById(friendId);
            if (friend == null) continue;

            friendItems.add(friend);
            shown++;
        }

        friendsList.setItems(friendItems);

        friendsList.setCellFactory(listView -> new ListCell<>() {
            @Override
            protected void updateItem(User friend, boolean empty) {
                super.updateItem(friend, empty);

                if (empty || friend == null) {
                    setText(null);
                    setGraphic(null);
                    setStyle("-fx-background-color: transparent; -fx-border-color: transparent;"); // تأكيد إخفاء الخطوط للخلايا الفارغة
                } else {
                    Label friendLabel = new Label("👤 " + friend.getUsername());
                    friendLabel.getStyleClass().add("card-title");

                    Button viewButton = new Button("View Wishlist");
                    viewButton.getStyleClass().add("link-button");
                    viewButton.setPrefSize(130, 36);

                    viewButton.setOnAction(event ->
                            Navigator.navigateTo(
                                    new FriendWishlistView().getView(user, friend)
                            )
                    );

                    HBox row = new HBox(14);
                    row.setAlignment(Pos.CENTER_LEFT);
                    row.getChildren().addAll(friendLabel, viewButton);

                    setGraphic(row);
                }
            }
        });

        if (friendItems.isEmpty()) {
            Label empty = new Label("No friends yet — send a request! 💌");
            empty.getStyleClass().add("card-sub");
            friendsList.setPlaceholder(empty);
        }

        // ==========================================
        // Recent Wishlist Activity
        // ==========================================

        Label activityTitle = new Label("Recent Wishlist Activity");
        activityTitle.getStyleClass().add("section-title");

        VBox activityList = new VBox(10);
        WishlistController wishlistController = new WishlistController();
        List<Item> myItems = wishlistController.getWishlist(user.getUserId());

        int limit = Math.min(4, myItems.size());
        for (int i = 0; i < limit; i++) {
            Item item = myItems.get(i);
            double contributed = wishlistController.getTotalContributed(user.getUserId(), item.getItemId());
            double price = item.getDefaultPrice();
            double pct = (price > 0) ? (contributed / price) * 100 : 0;

            String status = (pct >= 100) ? "✅ Fully funded!" : "💙 " + Math.round(pct) + "% funded";

            Label itemLabel = new Label("🎁 " + item.getName() + "  —  " + status);
            itemLabel.getStyleClass().add("card-title");

            activityList.getChildren().add(itemLabel);
        }

        if (activityList.getChildren().isEmpty()) {
            Label empty = new Label("Your wishlist is empty — add your first wish! 🎁");
            empty.getStyleClass().add("card-sub");
            activityList.getChildren().add(empty);
        }

        // ==========================================
        // Sections
        // ==========================================

        VBox friendsSection = new VBox(12);
        friendsSection.setPadding(new Insets(18, 0, 18, 0)); // تقليل الـ Padding الجانبي ليتناسق مع التصميم المسطح
        friendsSection.getChildren().addAll(friendsTitle, friendsList);

        VBox activitySection = new VBox(12);
        activitySection.setPadding(new Insets(18, 0, 18, 0));
        activitySection.getChildren().addAll(activityTitle, activityList);

        // ==========================================
        // Root / Content
        // ==========================================

        VBox content = new VBox(16);
        content.setPadding(new Insets(30));
        content.setAlignment(Pos.TOP_LEFT);
        // إضافة الكلاس إلى الـ content المستخدم فعلياً بدلاً من الـ root الذي لم يكن مستخدماً
        content.getStyleClass().add("root"); 

        content.getChildren().addAll(
                header,
                welcome,
                message,
                friendsSection,
                activitySection
        );

        ScrollPane scrollPane = new ScrollPane(content);
        scrollPane.setFitToWidth(true);
        // حل مشكلة الخلفية الرمادية الافتراضية في الـ ScrollPane وإجبارها على استخدام لون #F0F2F5
        scrollPane.setStyle("-fx-background: #F0F2F5; -fx-background-color: transparent; -fx-border-color: transparent;");

        return scrollPane;
    }
}