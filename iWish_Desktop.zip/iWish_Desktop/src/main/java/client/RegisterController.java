package client;

import database.UserDAO;
import model.User;

public class RegisterController {

    private UserDAO userDAO;

    public RegisterController() {
        userDAO = new UserDAO();
    }

    public String register(
            String username,
            String email,
            String password) {

        User user = new User(
                username,
                email,
                password
        );

        return userDAO.registerUser(user);
    }
}