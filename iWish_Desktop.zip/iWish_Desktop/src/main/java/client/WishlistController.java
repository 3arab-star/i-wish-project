package client;

import database.WishlistDAO;
import database.ContributionDAO;
import database.ItemDAO;
import database.UserDAO;
import database.NotificationDAO;
import model.Item;
import model.User;

import java.util.List;
import java.util.ArrayList;
import java.util.Objects;
import java.util.stream.Collectors;

public class WishlistController {

    private final WishlistDAO wishlistDAO;
    private final ContributionDAO contributionDAO;
    private final ItemDAO itemDAO;
    private final UserDAO userDAO;
    private final NotificationDAO notificationDAO;

    public WishlistController() {
        // Note: In a true client-server app, replace DAOs with network clients
        this.wishlistDAO = new WishlistDAO();
        this.contributionDAO = new ContributionDAO();
        this.itemDAO = new ItemDAO();
        this.userDAO = new UserDAO();
        this.notificationDAO = new NotificationDAO();
    }

    public boolean addItem(int userId, int itemId, double price) {
        return wishlistDAO.addToWishlist(userId, itemId, price);
    }

    public List<Item> getWishlist(int userId) {
        return wishlistDAO.getWishlist(userId);
    }

    public boolean removeItem(int userId, int itemId) {
        return wishlistDAO.removeFromWishlist(userId, itemId);
    }

    public String updateItem(int userId, int itemId, double newPrice) {
        int wishlistId = wishlistDAO.getWishlistId(userId, itemId);
        if (wishlistId == -1) return "Item not found in your wishlist.";

        double contributed = contributionDAO.getTotalContributed(wishlistId);
        if (contributed > 0) {
            return "This item already has contributions and its price can no longer be edited.";
        }

        boolean updated = wishlistDAO.updateWishlistItem(userId, itemId, newPrice);
        return updated ? "Price updated successfully!" : "Failed to update price.";
    }

    public double getTotalContributed(int ownerId, int itemId) {
        int wishlistId = wishlistDAO.getWishlistId(ownerId, itemId);
        return (wishlistId == -1) ? 0 : contributionDAO.getTotalContributed(wishlistId);
    }

    public double getRemainingAmount(int ownerId, int itemId) {
        int wishlistId = wishlistDAO.getWishlistId(ownerId, itemId);
        if (wishlistId == -1) return 0;

        double price = wishlistDAO.getPrice(wishlistId);
        double contributed = contributionDAO.getTotalContributed(wishlistId);
        return Math.max(price - contributed, 0);
    }
    
    // Added method required by the WishlistView
    public List<String> getContributors(int ownerId, int itemId) {
        int wishlistId = wishlistDAO.getWishlistId(ownerId, itemId);
        if (wishlistId == -1) return new ArrayList<>();
        
        List<Integer> buyerIds = contributionDAO.getBuyerIds(wishlistId);
        
        // Note: Optimize this in UserDAO with a single query fetching all users by ID list
        return buyerIds.stream()
                .map(userDAO::getUserById)
                .filter(Objects::nonNull)
                .map(User::getUsername)
                .collect(Collectors.toList());
    }

    public boolean contribute(int ownerId, int itemId, int buyerId, double amount) {
        int wishlistId = wishlistDAO.getWishlistId(ownerId, itemId);
        if (wishlistId == -1) return false;

        double totalBefore = contributionDAO.getTotalContributed(wishlistId);
        boolean success = contributionDAO.addContribution(wishlistId, buyerId, amount);
        
        if (!success) return false;

        double price = wishlistDAO.getPrice(wishlistId);
        double totalAfter = totalBefore + amount;

        if (totalBefore < price && totalAfter >= price) {
            notifyFullyFunded(ownerId, itemId, wishlistId);
        }

        return true;
    }

    private void notifyFullyFunded(int ownerId, int itemId, int wishlistId) {
        Item item = itemDAO.getItemById(itemId);
        User owner = userDAO.getUserById(ownerId);

        String itemName = (item != null) ? item.getName() : "an item";
        String ownerName = (owner != null) ? owner.getUsername() : "Your friend";

        List<Integer> buyerIds = contributionDAO.getBuyerIds(wishlistId);
        
        // Re-use the new getContributors logic for clean string building
        List<String> contributorNames = getContributors(ownerId, itemId);
        String buyerNamesString = String.join(", ", contributorNames);

        notificationDAO.addNotification(
                ownerId,
                "Great news! Your wish \"" + itemName + "\" has been fully funded by: " + buyerNamesString + "."
        );

        for (int buyerId : buyerIds) {
            notificationDAO.addNotification(
                    buyerId,
                    "The gift you contributed to for " + ownerName + "'s wish \"" + itemName + "\" has been completed!"
            );
        }
    }
}