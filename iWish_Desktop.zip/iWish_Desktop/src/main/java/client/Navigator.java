package client;

import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import model.User;
import java.util.Stack;

public class Navigator {

    private static Stage primaryStage;
    private static BorderPane mainLayout;
    private static final Stack<Node> history = new Stack<>();
    
    private static User currentUser;
    private static Node cachedSidebar; // Caches the sidebar to prevent rebuilding
    
    private static final String STYLESHEET = "/style.css";

    // ==========================================
    // Initialization
    // ==========================================

    public static void setPrimaryStage(Stage stage) {
        primaryStage = stage;
        mainLayout = new BorderPane();

        Scene scene = new Scene(mainLayout, 800, 600);
        if (Navigator.class.getResource(STYLESHEET) != null) {
            scene.getStylesheets().add(
                    Navigator.class.getResource(STYLESHEET).toExternalForm()
            );
        }

        primaryStage.setScene(scene);
        primaryStage.setTitle("iWish App");
    }

    // ==========================================
    // Current User & Sidebar Management
    // ==========================================

    public static void setCurrentUser(User user) {
        currentUser = user;
        
        // Build the sidebar ONCE when the user is set (e.g., on login)
        if (currentUser != null) {
            cachedSidebar = CreateSideBar.createSideBar(currentUser);
        } else {
            cachedSidebar = null;
        }
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    // ==========================================
    // Navigation
    // ==========================================

    public static void navigateTo(Parent root) {
        if (primaryStage == null || mainLayout == null) return;

        // Push current view to history before swapping
        if (mainLayout.getCenter() != null) {
            history.push(mainLayout.getCenter());
        }

        // FIX: Use the 'root' parameter passed to the method
        mainLayout.setCenter(root);

        // Use the pre-built sidebar instead of generating a new one
        mainLayout.setLeft(cachedSidebar);

        if (!primaryStage.isShowing()) {
            primaryStage.show();
        }
    }

    public static void goBack() {
        if (!history.isEmpty()) {
            Node previousRoot = history.pop();
            mainLayout.setCenter(previousRoot);
            
            // Keep the cached sidebar in place
            mainLayout.setLeft(cachedSidebar);
        }
    }

    public static void clearHistory() {
        history.clear();
    }

    // ==========================================
    // Rebuild SideBar (Manual trigger if user data changes)
    // ==========================================

    public static void rebuildSideBar() {
        if (currentUser != null && mainLayout != null) {
            cachedSidebar = CreateSideBar.createSideBar(currentUser);
            mainLayout.setLeft(cachedSidebar);
        }
    }
}