package client;

import database.ItemDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.Item;
import model.User;

import java.util.List;

public class WishlistView {

    public Parent getView(User user) {

        Label title = new Label("My Wishlist");
        title.getStyleClass().add("title");

        Label message = new Label(
                "Add the things you wish for and make your dreams come true. ✨"
        );
        message.getStyleClass().add("message");

        ListView<Item> wishlistList = new ListView<>();
        WishlistController wishlistController = new WishlistController();

        ObservableList<Item> wishlistItems = FXCollections.observableArrayList(
                wishlistController.getWishlist(user.getUserId())
        );

        wishlistList.setItems(wishlistItems);
        wishlistList.setPrefSize(700, 350);

        wishlistList.setCellFactory(listView -> new ListCell<>() {

            @Override
            protected void updateItem(Item item, boolean empty) {

                super.updateItem(item, empty);

                if (empty || item == null) {
                    setText(null);
                    setGraphic(null);

                } else {

                    double price = item.getDefaultPrice();
                    double contributed =
                            wishlistController.getTotalContributed(
                                    user.getUserId(),
                                    item.getItemId()
                            );

                    double pct = (price > 0)
                            ? (contributed / price) * 100
                            : 0;
                    if (pct > 100) pct = 100;

                    Label itemLabel = new Label(
                            item.getName()
                                    + " - "
                                    + price
                                    + " EGP  ("
                                    + Math.round(pct)
                                    + "% funded)"
                    );
                    itemLabel.getStyleClass().add("card-title");

                    ProgressBar progressBar = new ProgressBar(
                            pct / 100
                    );
                    progressBar.setPrefWidth(280);
                    progressBar.getStyleClass().add("progress-bar");
                    if (pct >= 100) {
                        progressBar.getStyleClass().add("funded");
                    }

                    Label contributorsLabel = new Label();
                    contributorsLabel.getStyleClass().add("card-sub");

                    List<String> contributors =
                            wishlistController.getContributors(
                                    user.getUserId(),
                                    item.getItemId()
                            );

                    if (contributors.isEmpty()) {
                        contributorsLabel.setText(
                                "No contributions yet — be the first!"
                        );
                    } else {
                        StringBuilder text = new StringBuilder(
                                "Top contributors: "
                        );
                        for (int i = 0; i < contributors.size() && i < 4; i++) {
                            if (i > 0) text.append("  •  ");
                            text.append(contributors.get(i));
                        }
                        contributorsLabel.setText(text.toString());
                    }

                    Button editButton = new Button("Edit");
                    editButton.getStyleClass().add("register-button");
                    editButton.setPrefSize(100, 40);

                    editButton.setOnAction(event ->
                            showEditItemWindow(
                                    user,
                                    item,
                                    wishlistList
                            )
                    );

                    Button removeButton = new Button("Remove");
                    removeButton.getStyleClass().add("link-button");
                    removeButton.setPrefSize(100, 40);

                    removeButton.setOnAction(event -> {

                        boolean removed =
                                wishlistController.removeItem(
                                        user.getUserId(),
                                        item.getItemId()
                                );

                        if (removed) {
                            wishlistItems.remove(item);
                        }
                    });

                    VBox info = new VBox(2);
                    info.setAlignment(Pos.CENTER_LEFT);
                    info.getChildren().addAll(
                            itemLabel,
                            progressBar,
                            contributorsLabel
                    );

                    VBox actions = new VBox(10);
                    actions.setAlignment(Pos.CENTER_RIGHT);
                    actions.getChildren().addAll(
                            editButton,
                            removeButton
                    );

                    HBox row = new HBox(20);
                    row.setAlignment(Pos.CENTER_LEFT);
                    row.getChildren().addAll(
                            info,
                            actions
                    );

                    setGraphic(row);
                }
            }
        });

        Button addNewButton = new Button("Add New Wish");
        addNewButton.getStyleClass().add("register-button");
        addNewButton.setPrefSize(200, 50);

        addNewButton.setOnAction(event ->
                showAddNewItemWindow(
                        user,
                        wishlistItems,
                        wishlistController
                )
        );

        Button chooseButton = new Button("Choose Existing Wish");
        chooseButton.getStyleClass().add("register-button");
        chooseButton.setPrefSize(200, 50);

        chooseButton.setOnAction(event ->
                showChooseExistingItemWindow(
                        user,
                        wishlistItems,
                        wishlistController
                )
        );

        HBox buttons = new HBox(20);
       buttons.setAlignment(Pos.CENTER);

        buttons.getChildren().addAll(
                addNewButton,
                chooseButton
        );

        VBox root = new VBox(18);
        root.setPadding(new Insets(30));
        root.setAlignment(Pos.CENTER);
        root.getStyleClass().add("register-root");

        root.getChildren().addAll(
                title,
                message,
                wishlistList,
                buttons
        );

        return root;
    }

    private void showAddNewItemWindow(
            User user,
            ObservableList<Item> wishlistItems,
            WishlistController wishlistController) {

        Stage stage = new Stage();

        Label title = new Label("Add New Wish");
        title.getStyleClass().add("title");

        TextField itemNameField = new TextField();
        itemNameField.setPromptText("Item Name");
        itemNameField.getStyleClass().add("input-field");

        TextField priceField = new TextField();
        priceField.setPromptText("Price (EGP)");
        priceField.getStyleClass().add("input-field");

        Label messageLabel = new Label();
        messageLabel.getStyleClass().add("message");

        Button addButton = new Button("Add Wish");
        addButton.getStyleClass().add("register-button");
        addButton.setPrefSize(200, 50);

        addButton.setOnAction(event -> {

            String itemName = itemNameField.getText().trim();
            String priceText = priceField.getText().trim();

            if (itemName.isEmpty() || priceText.isEmpty()) {
                messageLabel.setText("Please fill all fields.");
                return;
            }

            ItemDAO itemDAO = new ItemDAO();

            Item existingItemInDB =
                    itemDAO.findItemByName(itemName);

            if (existingItemInDB != null) {
                messageLabel.setText(
                        "Item already exists! Choose it from 'Choose Existing Wish'."
                );
                return;
            }

            double price;

            try {
                price = Double.parseDouble(priceText);

            } catch (NumberFormatException e) {
                messageLabel.setText("Please enter a valid price.");
                return;
            }

            if (price <= 0) {
                messageLabel.setText("Price must be greater than 0.");
                return;
            }

            Item item = new Item(itemName, price);

            int itemId = itemDAO.addItem(item);

            if (itemId == -1) {
                messageLabel.setText("Failed to create item.");
                return;
            }

            item.setItemId(itemId);

            boolean added =
                    wishlistController.addItem(
                            user.getUserId(),
                            itemId,
                            price
                    );

            if (added) {
                wishlistItems.add(item);
                messageLabel.setText("Wish added successfully!");
                itemNameField.clear();
                priceField.clear();
            } else {
                messageLabel.setText("Failed to add wish.");
            }
        });

        Button closeButton = new Button("Close");
        closeButton.getStyleClass().add("link-button");

        closeButton.setOnAction(event ->
                stage.close()
        );

        VBox root = new VBox(20);
        root.setPadding(new Insets(30));
        root.setAlignment(Pos.CENTER);
        root.getStyleClass().add("register-root");

        root.getChildren().addAll(
                title,
                itemNameField,
                priceField,
                addButton,
                messageLabel,
                closeButton
        );

        Scene scene = new Scene(root, 420, 420);
        scene.getStylesheets().add(
                getClass()
                        .getResource("/style.css")
                        .toExternalForm()
        );

        stage.setTitle("iWish - Add New Wish");
        stage.setScene(scene);
        stage.show();
    }

    private void showEditItemWindow(
            User user,
            Item item,
            ListView<Item> wishlistList) {

        Stage stage = new Stage();

        Label title = new Label(
                "Edit \"" + item.getName() + "\""
        );
        title.getStyleClass().add("title");

        TextField priceField = new TextField(
                String.valueOf(item.getDefaultPrice())
        );
        priceField.setPromptText("New Price (EGP)");
        priceField.getStyleClass().add("input-field");

        Label messageLabel = new Label();
        messageLabel.getStyleClass().add("message");

        Button saveButton = new Button("Save Changes");
        saveButton.getStyleClass().add("register-button");
        saveButton.setPrefSize(200, 50);

        WishlistController wishlistController =
                new WishlistController();

        saveButton.setOnAction(event -> {

            String priceText =
                    priceField.getText().trim();

            if (priceText.isEmpty()) {
                messageLabel.setText("Please enter a price.");
                return;
            }

            double newPrice;

            try {
                newPrice = Double.parseDouble(priceText);

            } catch (NumberFormatException e) {
                messageLabel.setText("Please enter a valid price.");
                return;
            }

            if (newPrice <= 0) {
                messageLabel.setText("Price must be greater than 0.");
                return;
            }

            String result =
                    wishlistController.updateItem(
                            user.getUserId(),
                            item.getItemId(),
                            newPrice
                    );

            messageLabel.setText(result);

            if (result.equals("Price updated successfully!")) {
                item.setDefaultPrice(newPrice);
                wishlistList.refresh();
            }
        });

        Button closeButton = new Button("Close");
        closeButton.getStyleClass().add("link-button");

        closeButton.setOnAction(event ->
                stage.close()
        );

        VBox root = new VBox(20);
        root.setPadding(new Insets(30));
        root.setAlignment(Pos.CENTER);
        root.getStyleClass().add("register-root");

        root.getChildren().addAll(
                title,
                priceField,
                saveButton,
                messageLabel,
                closeButton
        );

        Scene scene = new Scene(root, 400, 300);
        scene.getStylesheets().add(
                getClass()
                        .getResource("/style.css")
                        .toExternalForm()
        );

        stage.setTitle("iWish - Edit Wish");
        stage.setScene(scene);
        stage.show();
    }

    private void showChooseExistingItemWindow(
            User user,
            ObservableList<Item> wishlistItems,
            WishlistController wishlistController) {

        Stage stage = new Stage();

        Label title = new Label("Choose Existing Wish");
        title.getStyleClass().add("title");

        ItemDAO itemDAO = new ItemDAO();

        ObservableList<Item> allItems =
                FXCollections.observableArrayList(
                        itemDAO.getAllItems()
                );

        ListView<Item> itemList = new ListView<>();
        itemList.setItems(allItems);

        itemList.setCellFactory(listView ->
                new ListCell<>() {

                    @Override
                    protected void updateItem(
                            Item item,
                            boolean empty) {

                        super.updateItem(item, empty);

                        if (empty || item == null) {
                            setText(null);

                        } else {
                            setText(
                                    item.getName()
                                            + " - "
                                            + item.getDefaultPrice()
                                            + " EGP"
                            );
                        }
                    }
                }
        );

        Label messageLabel = new Label();
        messageLabel.getStyleClass().add("message");

        Button chooseButton =
                new Button("Add Selected Wish");

        chooseButton.getStyleClass()
                .add("register-button");

        chooseButton.setPrefSize(200, 50);

        chooseButton.setOnAction(event -> {

            Item selectedItem =
                    itemList.getSelectionModel()
                            .getSelectedItem();

            if (selectedItem == null) {
                messageLabel.setText("Please select an item.");
                return;
            }

            boolean alreadyExists =
                    wishlistItems.stream()
                            .anyMatch(item ->
                                    item.getItemId()
                                            == selectedItem.getItemId()
                                            ||
                                            item.getName()
                                                    .equalsIgnoreCase(
                                                            selectedItem.getName()
                                                    )
                            );

            if (alreadyExists) {
                messageLabel.setText("This item is already in your wishlist!");
                return;
            }

            boolean added =
                    wishlistController.addItem(
                            user.getUserId(),
                            selectedItem.getItemId(),
                            selectedItem.getDefaultPrice()
                    );

            if (added) {
                wishlistItems.add(selectedItem);
                messageLabel.setText("Wish added successfully!");
            } else {
                messageLabel.setText("Failed to add wish.");
            }
        });

        Button closeButton = new Button("Close");
        closeButton.getStyleClass().add("link-button");

        closeButton.setOnAction(
                event -> stage.close()
        );

        VBox root = new VBox(20);
        root.setPadding(new Insets(30));
        root.setAlignment(Pos.CENTER);
        root.getStyleClass().add("register-root");

        root.getChildren().addAll(
                title,
                itemList,
                chooseButton,
                messageLabel,
                closeButton
        );

        Scene scene = new Scene(root, 500, 500);
        scene.getStylesheets().add(
                getClass()
                        .getResource("/style.css")
                        .toExternalForm()
        );

        stage.setTitle("iWish - Choose Wish");
        stage.setScene(scene);
        stage.show();
    }
}
