package client;

import database.FriendDAO;
import database.UserDAO;
import database.NotificationDAO;
import model.FriendRequest;
import model.User;

import java.util.List;

public class FriendController {

    private FriendDAO friendDAO;
    private UserDAO userDAO;
    private NotificationDAO notificationDAO;

    public FriendController() {
        friendDAO = new FriendDAO();
        userDAO = new UserDAO();
        notificationDAO = new NotificationDAO();
    }

    // ==========================================
    // Send Friend Request
    // ==========================================

    public boolean sendRequest(
            int senderId,
            int receiverId) {

        boolean sent = friendDAO.sendFriendRequest(
                senderId,
                receiverId
        );

        if (sent) {

            User sender =
                    userDAO.getUserById(senderId);

            String senderUsername =
                    (sender != null)
                            ? sender.getUsername()
                            : "Someone";

            notificationDAO.addNotification(
                    receiverId,
                    senderUsername
                            + " sent you a friend request!"
            );
        }

        return sent;
    }

    // ==========================================
    // Get Pending Friend Requests
    // ==========================================

    public List<FriendRequest> getPendingRequests(
            int userId) {

        return friendDAO.getPendingRequests(
                userId
        );
    }

    // ==========================================
    // Accept Friend Request
    // ==========================================

    public boolean acceptRequest(
            int requestId,
            int senderId,
            int receiverId) {

        boolean accepted =
                friendDAO.acceptFriendRequest(
                        requestId,
                        senderId,
                        receiverId
                );

        if (accepted) {

            User receiver =
                    userDAO.getUserById(receiverId);

            String receiverUsername =
                    (receiver != null)
                            ? receiver.getUsername()
                            : "Someone";

            notificationDAO.addNotification(
                    senderId,
                    receiverUsername
                            + " accepted your friend request!"
            );
        }

        return accepted;
    }

    // ==========================================
    // Decline Friend Request
    // ==========================================

    public boolean declineRequest(
            int requestId) {

        return friendDAO.declineFriendRequest(
                requestId
        );
    }

    // ==========================================
    // Get Friends
    // ==========================================

    public List<Integer> getFriends(
            int userId) {

        return friendDAO.getFriends(
                userId
        );
    }

    // ==========================================
    // Remove Friend
    // ==========================================

    public boolean removeFriend(
            int userId,
            int friendId) {

        return friendDAO.removeFriend(
                userId,
                friendId
        );
    }

    // ==========================================
    // Get User By ID
    // ==========================================

    public User getUserById(
            int userId) {

        return userDAO.getUserById(
                userId
        );
    }

    // ==========================================
    // Get User By Email
    // ==========================================

    public User getUserByEmail(
            String email) {

        return userDAO.getUserByEmail(
                email
        );
    }

    // ==========================================
    // Search User By Username
    // ==========================================

    public User getUserByUsername(
            String username) {

        return userDAO.getUserByUsername(
                username
        );
    }
}