package client;

import database.NotificationDAO;
import model.Notification;

import java.util.List;

public class NotificationController {

    private NotificationDAO notificationDAO;

    public NotificationController() {
        notificationDAO = new NotificationDAO();
    }

    // ==========================================
    // Get Notifications For A User
    // ==========================================

    public List<Notification> getNotifications(
            int userId) {

        return notificationDAO.getNotifications(
                userId
        );
    }


    // ==========================================
    // Mark A Notification As Read
    // ==========================================

    public boolean markAsRead(
            int notificationId) {

        return notificationDAO.markAsRead(
                notificationId
        );
    }


    // ==========================================
    // Get Unread Notification Count
    // ==========================================

    public int getUnreadCount(
            int userId) {

        return notificationDAO.getUnreadCount(
                userId
        );
    }
}