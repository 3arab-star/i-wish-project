package server;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class ServerManager {
    private ServerSocket serverSocket;
    private boolean isRunning = false;
    private final List<ClientHandler> activeClients = new ArrayList<>();

    public void startServer(int port) {
        new Thread(() -> {
            try {
                serverSocket = new ServerSocket(port);
                isRunning = true;
                System.out.println("Server started on port " + port);

                while (isRunning) {
                    Socket socket = serverSocket.accept();
                    ClientHandler handler = new ClientHandler(socket, this);

                    synchronized (activeClients) {
                        activeClients.add(handler);
                    }

                    new Thread(handler).start();
                }
            } catch (Exception e) {
                System.out.println("Server stopped listening.");
            }
        }).start();
    }

    public void stopServer() {
        isRunning = false;
        try {
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close();
            }

            synchronized (activeClients) {
                for (ClientHandler client : activeClients) {
                    client.closeConnection();
                }
                activeClients.clear();
            }

            System.out.println("Server stopped successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public synchronized void removeClient(ClientHandler client) {
        activeClients.remove(client);
    }
}