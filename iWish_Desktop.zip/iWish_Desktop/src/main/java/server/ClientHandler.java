package server;

import database.*;
import model.*;
import java.io.*;
import java.net.Socket;
import java.util.List;

public class ClientHandler implements Runnable {
    private Socket socket;
    private ObjectInputStream in;
    private ObjectOutputStream out;
    private ServerManager serverManager;

    private UserDAO userDAO = new UserDAO();
    private FriendDAO friendDAO = new FriendDAO();
    private WishlistDAO wishlistDAO = new WishlistDAO();

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    public ClientHandler(Socket socket, ServerManager serverManager) {
        this.socket = socket;
        this.serverManager = serverManager;
    }

    @Override
    public void run() {
        try {
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());


            while (socket != null && !socket.isClosed()) {
                Object input = in.readObject();
                if (input == null) break;

                String action = (String) input;

                if ("LOGIN".equals(action)) {
                    String email = (String) in.readObject();
                    String password = (String) in.readObject();
                    User user = userDAO.loginUser(email, password);
                    out.writeObject(user);
                } else if ("REGISTER".equals(action)) {
                    User user = (User) in.readObject();
                    String result = userDAO.registerUser(user);
                    out.writeObject(result);
                } else if ("GET_FRIENDS".equals(action)) {
                    int userId = (Integer) in.readObject();
                    List<Integer> friends = friendDAO.getFriends(userId);
                    out.writeObject(friends);
                }
                out.flush();
            }
        } catch (Exception e) {
            System.out.println("Client disconnected or connection reset.");
        } finally {
            closeConnection();
        }
    }

    public void closeConnection() {
        try {
            if (serverManager != null) {
                serverManager.removeClient(this);
            }
            if (in != null) in.close();
            if (out != null) out.close();
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}