package server;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ServerControlView extends Application {

    private ServerManager serverManager = new ServerManager();
    private Label statusLabel = new Label("Server Status: STOPPED");

    @Override
    public void start(Stage primaryStage) {
        Button startButton = new Button("Start Server");
        Button stopButton = new Button("Stop Server");

        startButton.getStyleClass().add("register-button");
        stopButton.getStyleClass().add("link-button");
        stopButton.setDisable(true);

        startButton.setOnAction(e -> {
            try {
                serverManager.startServer(5000);
                statusLabel.setText("Server Status: RUNNING (Port 5000)");
                startButton.setDisable(true);
                stopButton.setDisable(false);
            } catch (Exception ex) {
                statusLabel.setText("Failed to start server.");
            }
        });

        stopButton.setOnAction(e -> {
            try {
                serverManager.stopServer();
                statusLabel.setText("Server Status: STOPPED");
                startButton.setDisable(false);
                stopButton.setDisable(true);
            } catch (Exception ex) {
                statusLabel.setText("Failed to stop server.");
            }
        });

        VBox root = new VBox(20, statusLabel, startButton, stopButton);
        root.setPadding(new Insets(30));
        root.setAlignment(Pos.CENTER);

        Scene scene = new Scene(root, 350, 250);
        primaryStage.setTitle("iWish - Server Control");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}